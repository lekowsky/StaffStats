package pl.kadrastats.staffstats;

import pl.kadrastats.staffstats.command.StaffCommand;
import pl.kadrastats.staffstats.gui.GuiListener;
import pl.kadrastats.staffstats.listener.AfkListener;
import pl.kadrastats.staffstats.listener.ConnectionListener;
import pl.kadrastats.staffstats.storage.DatabaseManager;
import pl.kadrastats.staffstats.tracker.ActivityTracker;
import pl.kadrastats.staffstats.util.LuckPermsHook;
import pl.kadrastats.staffstats.util.WebhookManager;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.logging.Level;

public final class StaffStatsPlugin extends JavaPlugin {

    private static StaffStatsPlugin instance;
    private DatabaseManager database;
    private ActivityTracker activityTracker;
    private LuckPermsHook luckPermsHook;
    private AfkListener afkListener;
    private WebhookManager webhook;

    @Override
    public void onLoad() { instance = this; }

    @Override
    public void onEnable() {
        saveDefaultConfig();

        try {
            database = new DatabaseManager(this);
            database.init();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "DB init failed", e);
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        if (getConfig().getBoolean("integrations.luckperms", true)) {
            luckPermsHook = new LuckPermsHook(this);
            luckPermsHook.init();
        }

        activityTracker = new ActivityTracker(this, database, luckPermsHook);

        webhook = new WebhookManager(this);
        
        Bukkit.getPluginManager().registerEvents(new ConnectionListener(this, activityTracker, webhook), this);
        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);

        if (getConfig().getBoolean("integrations.essentials-afk", true) && Bukkit.getPluginManager().getPlugin("Essentials") != null) {
            afkListener = new AfkListener(this, activityTracker);
            afkListener.register();
        }

        StaffCommand staffCmd = new StaffCommand(this, activityTracker, database);
        getCommand("staff").setExecutor(staffCmd);
        getCommand("staff").setTabCompleter(staffCmd);
        if (getCommand("staffstats") != null) {
            getCommand("staffstats").setExecutor(staffCmd);
            getCommand("staffstats").setTabCompleter(staffCmd);
        }

        Bukkit.getOnlinePlayers().forEach(p -> activityTracker.handleJoin(p, true));

        int period = getConfig().getInt("storage.periodic-save-minutes", 0);
        if (period > 0) {
            Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> activityTracker.saveAllOnline(false),
                    period * 60L * 20L, period * 60L * 20L);
        }

        scheduleDailySummary();

        getLogger().info("StaffStats v" + getDescription().getVersion() + " enabled. /staff GUI ready.");
    }

    @Override
    public void onDisable() {
        if (activityTracker != null) activityTracker.saveAllOnline(true);
        if (database != null) database.shutdown();
        if (webhook != null) webhook.shutdown();
    }

    public void reloadPlugin() {
        reloadConfig();
        activityTracker.reloadConfigCache();
        if (webhook != null) webhook.reload();
        getLogger().info("StaffStats reload complete.");
    }

    private void scheduleDailySummary() {
        int hour = getConfig().getInt("webhook.daily-summary-hour", -1);
        if (hour < 0 || hour > 23) return;
        if (webhook == null || !webhook.isEnabled()) return;

        Runnable task = () -> {
            webhook.sendDailySummary(database);
            scheduleDailySummary(); // reschedule next day
        };
        ZoneId zone = ZoneId.of("Europe/Warsaw");
        ZonedDateTime now = ZonedDateTime.now(zone);
        ZonedDateTime next = now.withHour(hour).withMinute(0).withSecond(5);
        if (!next.isAfter(now)) next = next.plusDays(1);
        long delayTicks = Duration.between(now, next).getSeconds() * 20L;
        Bukkit.getScheduler().runTaskLaterAsynchronously(this, task, delayTicks);
        getLogger().info("Daily Discord summary scheduled at " + hour + ":00 Europe/Warsaw (in " + Duration.between(now, next).toHours() + "h)");
    }

    public static StaffStatsPlugin getInstance() { return instance; }
    public DatabaseManager getDatabase() { return database; }
    public ActivityTracker getActivityTracker() { return activityTracker; }
    public LuckPermsHook getLuckPermsHook() { return luckPermsHook; }
    public WebhookManager getWebhook() { return webhook; }
}
