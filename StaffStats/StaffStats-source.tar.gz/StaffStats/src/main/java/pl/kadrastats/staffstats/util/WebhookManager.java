package pl.kadrastats.staffstats.util;

import pl.kadrastats.staffstats.StaffStatsPlugin;
import pl.kadrastats.staffstats.storage.DatabaseManager;
import pl.kadrastats.staffstats.storage.StaffRecord;
import pl.kadrastats.staffstats.tracker.ActivityTracker;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;

public class WebhookManager {

    private final StaffStatsPlugin plugin;
    private ExecutorService pool;
    private String url;
    private boolean enabled;
    private String username;
    private String avatar;

    public WebhookManager(StaffStatsPlugin plugin) {
        this.plugin = plugin;
        reload();
        pool = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "StaffStats-Webhook");
            t.setDaemon(true);
            return t;
        });
    }

    public void reload() {
        enabled = plugin.getConfig().getBoolean("webhook.enabled", false);
        url = plugin.getConfig().getString("webhook.url", "");
        username = plugin.getConfig().getString("webhook.username", "StaffStats");
        avatar = plugin.getConfig().getString("webhook.avatar-url", "");
        if (enabled && (url == null || url.isBlank() || url.contains("TWOJE_ID"))) {
            plugin.getLogger().warning("Webhook włączony ale URL jest pusty / przykładowy – wyłączam.");
            enabled = false;
        }
    }

    public boolean isEnabled() { return enabled && url != null && url.startsWith("http"); }

    public void sendJoin(String player, String group) {
        if (!isEnabled() || !plugin.getConfig().getBoolean("webhook.send-on-staff-join", true)) return;
        JsonObject embed = new JsonObject();
        embed.addProperty("title", "🟢 " + player + " dołączył");
        embed.addProperty("description", "**Ranga:** `" + group + "`\n**Czas:** <t:" + Instant.now().getEpochSecond() + ":F>");
        embed.addProperty("color", plugin.getConfig().getInt("webhook.color-join", 65280));
        sendEmbed(embed);
    }

    public void sendQuit(ActivityTracker.SessionResult res) {
        if (!isEnabled() || !plugin.getConfig().getBoolean("webhook.send-on-staff-quit", true)) return;
        int min = plugin.getConfig().getInt("webhook.min-quit-session-minutes", 5);
        if (res.playtimeMs() < min * 60_000L) return;
        JsonObject embed = new JsonObject();
        embed.addProperty("title", "🔴 " + res.name() + " opuścił serwer");
        String desc = "**Ranga:** `" + res.group() + "`\n" +
                "**Sesja:** " + StaffRecord.formatDuration(res.playtimeMs()) + "\n" +
                "**AFK w sesji:** " + StaffRecord.formatDuration(res.afkMs()) + "\n" +
                "**Aktywny:** " + StaffRecord.formatDuration(Math.max(0, res.playtimeMs() - res.afkMs()));
        embed.addProperty("description", desc);
        embed.addProperty("color", plugin.getConfig().getInt("webhook.color-quit", 16711680));
        embed.addProperty("timestamp", Instant.now().toString());
        sendEmbed(embed);
    }

    public void sendDailySummary(DatabaseManager db) {
        if (!isEnabled()) return;
        List<StaffRecord> top = db.getTop(null, 10);
        if (top.isEmpty()) return;
        JsonObject embed = new JsonObject();
        embed.addProperty("title", "📊 Dzienny raport kadry");
        embed.addProperty("color", 3447003);
        StringBuilder sb = new StringBuilder();
        int i=1;
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.of("Europe/Warsaw"));
        for (StaffRecord r : top) {
            sb.append("**").append(i).append(". ").append(r.name).append("** `[").append(r.group).append("]`\n")
              .append("⏱ ").append(StaffRecord.formatDuration(r.activeMs()))
              .append(" | AFK ").append(StaffRecord.formatDuration(r.totalAfkMs))
              .append(" | sesji ").append(r.sessionCount).append("\n");
            i++;
        }
        embed.addProperty("description", sb.toString());
        // footer dodawany w sendEmbed
        embed.addProperty("timestamp", Instant.now().toString());
        sendEmbed(embed, "Podsumowanie " + fmt.format(Instant.now()));
    }

    private void sendEmbed(JsonObject embed) { sendEmbed(embed, null); }

    private void sendEmbed(JsonObject embed, String footerText) {
        if (!isEnabled()) return;
        pool.submit(() -> {
            try {
                JsonObject payload = new JsonObject();
                payload.addProperty("username", username);
                if (avatar != null && !avatar.isBlank()) payload.addProperty("avatar_url", avatar);
                JsonArray embeds = new JsonArray();
                if (footerText != null) {
                    JsonObject footer = new JsonObject();
                    footer.addProperty("text", footerText);
                    embed.add("footer", footer);
                }
                embeds.add(embed);
                payload.add("embeds", embeds);

                byte[] data = payload.toString().getBytes(StandardCharsets.UTF_8);
                HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.setRequestProperty("Content-Type", "application/json");
                con.setRequestProperty("User-Agent", "StaffStats/1.1");
                try (OutputStream os = con.getOutputStream()) { os.write(data); }
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) {
                    plugin.getLogger().warning("Webhook HTTP " + code);
                }
                con.disconnect();
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Webhook send failed", e);
            }
        });
    }

    public void shutdown() {
        if (pool != null) pool.shutdownNow();
    }
}
