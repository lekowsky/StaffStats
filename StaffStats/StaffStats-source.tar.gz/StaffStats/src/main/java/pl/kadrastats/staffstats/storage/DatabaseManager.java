package pl.kadrastats.staffstats.storage;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;

public class DatabaseManager {

    private final JavaPlugin plugin;
    private Connection connection;
    private final ExecutorService asyncPool;
    private final boolean asyncWrites;

    public DatabaseManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.asyncPool = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "StaffStats-DB");
            t.setDaemon(true);
            return t;
        });
        this.asyncWrites = plugin.getConfig().getBoolean("storage.async-writes", true);
    }

    public void init() throws SQLException {
        File dbFile = new File(plugin.getDataFolder(), "staff_activity.db");
        if (!dbFile.getParentFile().exists()) dbFile.getParentFile().mkdirs();
        String url = "jdbc:sqlite:" + dbFile.getAbsolutePath();
        try { Class.forName("org.sqlite.JDBC"); } catch (ClassNotFoundException e) { throw new SQLException(e); }
        connection = DriverManager.getConnection(url);
        try (Statement st = connection.createStatement()) {
            st.executeUpdate("PRAGMA journal_mode=WAL;");
            st.executeUpdate("PRAGMA synchronous=NORMAL;");
        }
        createTables();
        plugin.getLogger().info("SQLite connected: " + dbFile.getName());
    }

    private void createTables() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS staff_stats (
                    uuid TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    group_name TEXT,
                    total_playtime_ms INTEGER NOT NULL DEFAULT 0,
                    total_afk_ms INTEGER NOT NULL DEFAULT 0,
                    last_login INTEGER DEFAULT 0,
                    last_logout INTEGER DEFAULT 0,
                    session_count INTEGER NOT NULL DEFAULT 0,
                    first_seen INTEGER DEFAULT 0,
                    updated_at INTEGER NOT NULL
                );
                """);
            st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_group ON staff_stats(group_name);");
            st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_playtime ON staff_stats(total_playtime_ms DESC);");
        }
    }

    public void upsertSession(UUID uuid, String name, String group,
                              long playtimeAdd, long afkAdd,
                              long loginTs, long logoutTs, boolean incrementSession) {
        Runnable task = () -> {
            try {
                String sql = """
                    INSERT INTO staff_stats (uuid, name, group_name, total_playtime_ms, total_afk_ms, last_login, last_logout, session_count, first_seen, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(uuid) DO UPDATE SET
                        name = excluded.name,
                        group_name = COALESCE(excluded.group_name, group_name),
                        total_playtime_ms = total_playtime_ms + excluded.total_playtime_ms,
                        total_afk_ms = total_afk_ms + excluded.total_afk_ms,
                        last_login = CASE WHEN excluded.last_login > last_login THEN excluded.last_login ELSE last_login END,
                        last_logout = CASE WHEN excluded.last_logout > last_logout THEN excluded.last_logout ELSE last_logout END,
                        session_count = session_count + ?,
                        updated_at = excluded.updated_at
                    ;
                    """;
                long now = System.currentTimeMillis();
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setString(1, uuid.toString());
                    ps.setString(2, name);
                    ps.setString(3, group);
                    ps.setLong(4, playtimeAdd);
                    ps.setLong(5, afkAdd);
                    ps.setLong(6, loginTs);
                    ps.setLong(7, logoutTs);
                    ps.setInt(8, incrementSession ? 1 : 0);
                    ps.setLong(9, now);
                    ps.setLong(10, now);
                    ps.setInt(11, incrementSession ? 1 : 0);
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "DB upsert failed " + uuid, e);
            }
        };
        if (asyncWrites) asyncPool.execute(task); else task.run();
    }

    public void updateLogin(UUID uuid, String name, String group, long loginTs) {
        upsertSession(uuid, name, group, 0, 0, loginTs, 0, false);
    }

    public StaffRecord getRecord(UUID uuid) {
        String sql = "SELECT * FROM staff_stats WHERE uuid = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return map(rs); }
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "getRecord", e); }
        return null;
    }

    public CompletableFuture<StaffRecord> getRecordAsync(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> getRecord(uuid), asyncPool);
    }

    public List<StaffRecord> getTop(String groupFilter, int limit) {
        List<StaffRecord> list = new ArrayList<>();
        String sql = groupFilter == null
                ? "SELECT * FROM staff_stats ORDER BY total_playtime_ms DESC LIMIT ?"
                : "SELECT * FROM staff_stats WHERE group_name = ? COLLATE NOCASE ORDER BY total_playtime_ms DESC LIMIT ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            if (groupFilter == null) ps.setInt(1, limit);
            else { ps.setString(1, groupFilter); ps.setInt(2, limit); }
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "getTop", e); }
        return list;
    }

    public List<StaffRecord> getByGroup(String group) {
        List<StaffRecord> list = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM staff_stats WHERE group_name = ? COLLATE NOCASE ORDER BY total_playtime_ms DESC")) {
            ps.setString(1, group);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "getByGroup", e); }
        return list;
    }

    public List<StaffRecord> getAll(int limit) {
        List<StaffRecord> list = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM staff_stats ORDER BY total_playtime_ms DESC LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "getAll", e); }
        return list;
    }

    public boolean resetPlayer(UUID uuid) {
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM staff_stats WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "reset", e); return false; }
    }

    private StaffRecord map(ResultSet rs) throws SQLException {
        return new StaffRecord(
                UUID.fromString(rs.getString("uuid")),
                rs.getString("name"),
                rs.getString("group_name"),
                rs.getLong("total_playtime_ms"),
                rs.getLong("total_afk_ms"),
                rs.getLong("last_login"),
                rs.getLong("last_logout"),
                rs.getInt("session_count"),
                rs.getLong("first_seen")
        );
    }

    public void shutdown() {
        try {
            asyncPool.shutdown();
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException ignored) {}
    }
}
