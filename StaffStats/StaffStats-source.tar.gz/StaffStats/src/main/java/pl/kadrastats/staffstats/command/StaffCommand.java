package pl.kadrastats.staffstats.command;

import pl.kadrastats.staffstats.StaffStatsPlugin;
import pl.kadrastats.staffstats.gui.StaffGui;
import pl.kadrastats.staffstats.storage.DatabaseManager;
import pl.kadrastats.staffstats.storage.StaffRecord;
import pl.kadrastats.staffstats.tracker.ActivityTracker;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class StaffCommand implements CommandExecutor, TabCompleter {

    private final StaffStatsPlugin plugin;
    private final ActivityTracker tracker;
    private final DatabaseManager db;
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public StaffCommand(StaffStatsPlugin plugin, ActivityTracker tracker, DatabaseManager db) {
        this.plugin = plugin;
        this.tracker = tracker;
        this.db = db;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("staffstats.view")) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.prefix") + plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        // /staff reload (admin)
        if (args.length == 1 && args[0].equalsIgnoreCase("reload") && sender.hasPermission("staffstats.admin")) {
            plugin.reloadPlugin();
            sender.sendMessage(color("&aStaffStats przeładowano."));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reset") && sender.hasPermission("staffstats.admin")) {
            sender.sendMessage(color("&cUżycie: /" + label + " reset <gracz>"));
            return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("reset") && sender.hasPermission("staffstats.admin")) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(args[1]);
            boolean ok = db.resetPlayer(op.getUniqueId());
            sender.sendMessage(ok ? color("&aZresetowano " + args[1]) : color("&cBrak danych."));
            return true;
        }

        // /staff <gracz>  -> szybki raport w chacie (dla konsoli / wygodne)
        if (args.length >= 1 && !args[0].equalsIgnoreCase("reload") && !args[0].equalsIgnoreCase("reset")) {
            String targetName = args[0];
            OfflinePlayer op = Bukkit.getOfflinePlayer(targetName);
            sendQuickReport(sender, op.getUniqueId());
            return true;
        }

        // GUI – tylko gracz
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Użyj: /staff <nick>  (konsola nie ma GUI)");
            // wypisz top 10
            List<StaffRecord> top = db.getTop(null, 10);
            sender.sendMessage("=== TOP KADRA ===");
            int i=1;
            for (StaffRecord r : top) {
                sender.sendMessage(i + ". " + r.name + " - " + StaffRecord.formatDuration(r.activeMs()));
                i++;
            }
            return true;
        }

        // cooldown
        long now = System.currentTimeMillis()/1000;
        long last = cooldown.getOrDefault(p.getUniqueId(), 0L);
        int cd = plugin.getConfig().getInt("performance.command-cooldown-seconds", 2);
        if (now - last < cd && !p.hasPermission("staffstats.admin")) {
            p.sendMessage(color("&cPoczekaj " + (cd - (now-last)) + "s"));
            return true;
        }
        cooldown.put(p.getUniqueId(), now);

        p.sendMessage(color(plugin.getConfig().getString("messages.gui-opening", "&7Otwieram panel kadry...")));
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            var inv = StaffGui.build(plugin);
            Bukkit.getScheduler().runTask(plugin, () -> p.openInventory(inv));
        });
        return true;
    }

    private void sendQuickReport(CommandSender sender, UUID uuid) {
        StaffRecord rec = db.getRecord(uuid);
        ActivityTracker.Session live = tracker.getSession(uuid);
        if (rec == null && live == null) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.player-not-tracked")));
            return;
        }
        String name = rec != null ? rec.name : Bukkit.getOfflinePlayer(uuid).getName();
        long totalPlay = rec != null ? rec.totalPlaytimeMs : 0;
        long totalAfk = rec != null ? rec.totalAfkMs : 0;
        if (live != null) { totalPlay += live.currentPlaytime(); totalAfk += live.currentAfk(); }
        sender.sendMessage(color("&b" + name + " §8» §a" + StaffRecord.formatDuration(totalPlay) + " §7(AF K " + StaffRecord.formatDuration(totalAfk) + ") " + (live != null ? "§aONLINE" : "§7offline")));
    }

    private String color(String s){ return s == null ? "" : s.replace('&','§'); }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = new ArrayList<>();
            if (sender.hasPermission("staffstats.admin")) {
                out.add("reload");
                out.add("reset");
            }
            // gracze online
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
            // dodaj znanych z bazy
            db.getAll(30).forEach(r -> { if (!out.contains(r.name)) out.add(r.name); });
            String low = args[0].toLowerCase();
            return out.stream().filter(s -> s.toLowerCase().startsWith(low)).sorted().limit(20).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("reset") && sender.hasPermission("staffstats.admin")) {
            return db.getAll(50).stream().map(r -> r.name).filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
